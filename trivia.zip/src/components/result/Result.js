import React from 'react'

function Result() {
  return (
    <section className="quiz">
        <h4>Result</h4>
    </section>
  )
}

export default Result
